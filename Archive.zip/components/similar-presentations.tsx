import { presentations } from "@/lib/mock-data"
import { PresentationCard } from "./presentation-card"

interface SimilarPresentationsProps {
  currentId: string
  category: string
}

export function SimilarPresentations({ currentId, category }: SimilarPresentationsProps) {
  const similar = presentations.filter((p) => p.category === category && p.id !== currentId).slice(0, 3)

  return (
    <section className="py-12">
      <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-6">Similar Presentations</h2>
      <div className="grid md:grid-cols-3 gap-6">
        {similar.length > 0 ? (
          similar.map((presentation) => <PresentationCard key={presentation.id} presentation={presentation} />)
        ) : (
          <p className="text-muted-foreground">No similar presentations found</p>
        )}
      </div>
    </section>
  )
}
