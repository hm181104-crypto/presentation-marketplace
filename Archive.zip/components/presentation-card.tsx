import Link from "next/link"
import Image from "next/image"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import type { Presentation } from "@/lib/types"
import { Star, Sliders as Slides } from "lucide-react"

interface PresentationCardProps {
  presentation: Presentation
}

export function PresentationCard({ presentation }: PresentationCardProps) {
  return (
    <Card className="overflow-hidden hover:shadow-lg transition flex flex-col h-full">
      <div className="relative h-48 bg-muted">
        <Image
          src={presentation.thumbnail || "/placeholder.svg"}
          alt={presentation.title}
          fill
          className="object-cover"
        />
        <div className="absolute top-3 right-3 bg-primary text-primary-foreground px-3 py-1 rounded-full text-sm font-semibold">
          ${presentation.price}
        </div>
        <div className="absolute top-3 left-3 bg-accent text-accent-foreground px-2 py-1 rounded text-xs font-medium">
          {presentation.fileType}
        </div>
      </div>
      <div className="p-4 flex-1 flex flex-col">
        <Link href={`/presentation/${presentation.id}`}>
          <h3 className="font-bold text-lg text-foreground hover:text-primary transition line-clamp-2">
            {presentation.title}
          </h3>
        </Link>
        <p className="text-xs text-muted-foreground mt-1">
          {presentation.category} • {presentation.level}
        </p>
        <p className="text-sm text-muted-foreground mt-2 line-clamp-2 flex-1">{presentation.description}</p>
        <div className="mt-4 flex items-center gap-4 text-xs">
          <div className="flex items-center gap-1">
            <Star className="h-4 w-4 fill-accent text-accent" />
            <span className="font-semibold">{presentation.rating}</span>
            <span className="text-muted-foreground">({presentation.reviewCount})</span>
          </div>
          <div className="flex items-center gap-1">
            <Slides className="h-4 w-4 text-muted-foreground" />
            <span>{presentation.slideCount} slides</span>
          </div>
        </div>
        <div className="mt-4">
          <Button className="w-full" asChild>
            <Link href={`/presentation/${presentation.id}`}>View Details</Link>
          </Button>
        </div>
      </div>
    </Card>
  )
}
