import Link from "next/link"
import { categories } from "@/lib/mock-data"
import { Card } from "@/components/ui/card"

export function CategoriesSection() {
  return (
    <section className="py-16 md:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Popular Categories</h2>
          <p className="text-muted-foreground text-lg">Explore presentations across various industries</p>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {categories.map((category) => (
            <Link key={category.id} href={`/marketplace?category=${category.name}`}>
              <Card className="p-4 text-center hover:border-accent hover:shadow-md transition cursor-pointer h-full flex flex-col items-center justify-center gap-3">
                <span className="text-4xl">{category.icon}</span>
                <span className="font-semibold text-foreground text-sm md:text-base">{category.name}</span>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}
