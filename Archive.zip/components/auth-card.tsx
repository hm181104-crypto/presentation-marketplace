import type React from "react"
import { Card } from "@/components/ui/card"
import Link from "next/link"

interface AuthCardProps {
  title: string
  description: string
  children: React.ReactNode
  footerLink?: { text: string; href: string }
}

export function AuthCard({ title, description, children, footerLink }: AuthCardProps) {
  return (
    <Card className="w-full max-w-md p-8">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-foreground mb-2">{title}</h1>
        <p className="text-muted-foreground">{description}</p>
      </div>

      {children}

      {footerLink && (
        <p className="mt-6 text-center text-sm text-muted-foreground">
          {footerLink.text.split("|")[0]}
          <Link href={footerLink.href} className="text-primary hover:text-primary/80 transition ml-1">
            {footerLink.text.split("|")[1]}
          </Link>
        </p>
      )}
    </Card>
  )
}
