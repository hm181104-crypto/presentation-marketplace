"use client"

import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Search, X } from "lucide-react"
import { categories } from "@/lib/mock-data"

interface MarketplaceFiltersProps {
  onFilterChange: (filters: any) => void
  searchTerm: string
  selectedCategory: string
  minPrice: number
  maxPrice: number
  selectedFileType: string
  selectedLevel: string
}

export function MarketplaceFilters({
  onFilterChange,
  searchTerm,
  selectedCategory,
  minPrice,
  maxPrice,
  selectedFileType,
  selectedLevel,
}: MarketplaceFiltersProps) {
  const fileTypes = ["PPT", "Google Slides", "Canva"]
  const levels = ["Student", "Business", "Pitch Deck"]

  const hasActiveFilters =
    searchTerm ||
    selectedCategory !== "all" ||
    minPrice > 0 ||
    maxPrice < 100 ||
    selectedFileType !== "all" ||
    selectedLevel !== "all"

  return (
    <div className="space-y-6">
      {/* Search */}
      <Card className="p-4">
        <div className="relative">
          <Search className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
          <Input
            placeholder="Search presentations..."
            className="pl-10"
            value={searchTerm}
            onChange={(e) => onFilterChange({ searchTerm: e.target.value })}
          />
        </div>
      </Card>

      {/* Categories */}
      <Card className="p-4">
        <h3 className="font-semibold text-foreground mb-3">Category</h3>
        <div className="space-y-2">
          <label className="flex items-center gap-2 cursor-pointer hover:text-primary transition">
            <input
              type="radio"
              name="category"
              value="all"
              checked={selectedCategory === "all"}
              onChange={(e) => onFilterChange({ selectedCategory: e.target.value })}
              className="cursor-pointer"
            />
            <span>All Categories</span>
          </label>
          {categories.map((cat) => (
            <label key={cat.id} className="flex items-center gap-2 cursor-pointer hover:text-primary transition">
              <input
                type="radio"
                name="category"
                value={cat.name}
                checked={selectedCategory === cat.name}
                onChange={(e) => onFilterChange({ selectedCategory: e.target.value })}
                className="cursor-pointer"
              />
              <span>
                {cat.icon} {cat.name}
              </span>
            </label>
          ))}
        </div>
      </Card>

      {/* Price Range */}
      <Card className="p-4">
        <h3 className="font-semibold text-foreground mb-3">Price Range</h3>
        <div className="space-y-3">
          <div>
            <label className="text-sm text-muted-foreground">Min: ${minPrice}</label>
            <input
              type="range"
              min="0"
              max="100"
              value={minPrice}
              onChange={(e) => onFilterChange({ minPrice: Number.parseInt(e.target.value) })}
              className="w-full"
            />
          </div>
          <div>
            <label className="text-sm text-muted-foreground">Max: ${maxPrice}</label>
            <input
              type="range"
              min="0"
              max="100"
              value={maxPrice}
              onChange={(e) => onFilterChange({ maxPrice: Number.parseInt(e.target.value) })}
              className="w-full"
            />
          </div>
        </div>
      </Card>

      {/* File Type */}
      <Card className="p-4">
        <h3 className="font-semibold text-foreground mb-3">File Type</h3>
        <div className="space-y-2">
          <label className="flex items-center gap-2 cursor-pointer hover:text-primary transition">
            <input
              type="radio"
              name="filetype"
              value="all"
              checked={selectedFileType === "all"}
              onChange={(e) => onFilterChange({ selectedFileType: e.target.value })}
              className="cursor-pointer"
            />
            <span>All Types</span>
          </label>
          {fileTypes.map((type) => (
            <label key={type} className="flex items-center gap-2 cursor-pointer hover:text-primary transition">
              <input
                type="radio"
                name="filetype"
                value={type}
                checked={selectedFileType === type}
                onChange={(e) => onFilterChange({ selectedFileType: e.target.value })}
                className="cursor-pointer"
              />
              <span>{type}</span>
            </label>
          ))}
        </div>
      </Card>

      {/* Level */}
      <Card className="p-4">
        <h3 className="font-semibold text-foreground mb-3">Level</h3>
        <div className="space-y-2">
          <label className="flex items-center gap-2 cursor-pointer hover:text-primary transition">
            <input
              type="radio"
              name="level"
              value="all"
              checked={selectedLevel === "all"}
              onChange={(e) => onFilterChange({ selectedLevel: e.target.value })}
              className="cursor-pointer"
            />
            <span>All Levels</span>
          </label>
          {levels.map((level) => (
            <label key={level} className="flex items-center gap-2 cursor-pointer hover:text-primary transition">
              <input
                type="radio"
                name="level"
                value={level}
                checked={selectedLevel === level}
                onChange={(e) => onFilterChange({ selectedLevel: e.target.value })}
                className="cursor-pointer"
              />
              <span>{level}</span>
            </label>
          ))}
        </div>
      </Card>

      {/* Clear Filters */}
      {hasActiveFilters && (
        <Button
          variant="outline"
          className="w-full bg-transparent"
          onClick={() => {
            onFilterChange({
              searchTerm: "",
              selectedCategory: "all",
              minPrice: 0,
              maxPrice: 100,
              selectedFileType: "all",
              selectedLevel: "all",
            })
          }}
        >
          <X className="h-4 w-4 mr-2" />
          Clear Filters
        </Button>
      )}
    </div>
  )
}
