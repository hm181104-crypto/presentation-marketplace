import Link from "next/link"
import Image from "next/image"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { presentations } from "@/lib/mock-data"
import { Star } from "lucide-react"

export function FeaturedSection() {
  const featured = presentations.slice(0, 3)

  return (
    <section className="py-16 md:py-24 bg-muted/30">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Featured Presentations</h2>
          <p className="text-muted-foreground text-lg">Best sellers from our marketplace</p>
        </div>
        <div className="grid md:grid-cols-3 gap-6">
          {featured.map((presentation) => (
            <Card key={presentation.id} className="overflow-hidden hover:shadow-lg transition flex flex-col h-full">
              <div className="relative h-48 bg-muted">
                <Image
                  src={presentation.thumbnail || "/placeholder.svg"}
                  alt={presentation.title}
                  fill
                  className="object-cover"
                />
                <div className="absolute top-3 right-3 bg-accent text-accent-foreground px-3 py-1 rounded-full text-sm font-semibold">
                  ${presentation.price}
                </div>
              </div>
              <div className="p-4 flex-1 flex flex-col">
                <Link href={`/presentation/${presentation.id}`}>
                  <h3 className="font-bold text-lg text-foreground hover:text-primary transition line-clamp-2">
                    {presentation.title}
                  </h3>
                </Link>
                <p className="text-sm text-muted-foreground mt-2 line-clamp-2 flex-1">{presentation.description}</p>
                <div className="mt-4 flex items-center justify-between">
                  <div className="flex items-center gap-1">
                    <Star className="h-4 w-4 fill-accent text-accent" />
                    <span className="font-semibold text-sm">{presentation.rating}</span>
                    <span className="text-xs text-muted-foreground">({presentation.reviewCount})</span>
                  </div>
                  <Button size="sm" asChild>
                    <Link href={`/presentation/${presentation.id}`}>View</Link>
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
