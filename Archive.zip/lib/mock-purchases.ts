import type { Purchase } from "./types"

export const mockPurchases: Purchase[] = [
  {
    id: "1",
    buyerId: "buyer1",
    presentationId: "1",
    price: 29.99,
    purchasedAt: new Date("2024-10-20"),
  },
  {
    id: "2",
    buyerId: "buyer1",
    presentationId: "2",
    price: 19.99,
    purchasedAt: new Date("2024-10-15"),
  },
  {
    id: "3",
    buyerId: "buyer1",
    presentationId: "5",
    price: 34.99,
    purchasedAt: new Date("2024-10-10"),
  },
  {
    id: "4",
    buyerId: "buyer1",
    presentationId: "3",
    price: 39.99,
    purchasedAt: new Date("2024-09-28"),
  },
]
