import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { SellerDashboardTable } from "@/components/seller-dashboard-table"
import { presentations } from "@/lib/mock-data"
import { Plus, DollarSign, FileText, TrendingUp } from "lucide-react"

export default function SellerDashboardPage() {
  const sellerPresentations = presentations.filter((p) => p.creatorId === "creator1")
  const totalSales = sellerPresentations.reduce((sum, p) => sum + p.price * p.reviewCount, 0)
  const totalDownloads = sellerPresentations.reduce((sum, p) => sum + p.reviewCount, 0)
  const avgRating = (sellerPresentations.reduce((sum, p) => sum + p.rating, 0) / sellerPresentations.length).toFixed(1)

  const stats = [
    {
      icon: FileText,
      label: "Total Presentations",
      value: sellerPresentations.length,
      color: "text-primary",
    },
    {
      icon: DollarSign,
      label: "Total Earnings",
      value: `$${totalSales.toFixed(2)}`,
      color: "text-accent",
    },
    {
      icon: TrendingUp,
      label: "Total Downloads",
      value: totalDownloads,
      color: "text-primary",
    },
    {
      icon: FileText,
      label: "Average Rating",
      value: avgRating,
      color: "text-accent",
    },
  ]

  return (
    <main className="bg-background">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
          <div>
            <h1 className="text-4xl font-bold text-foreground mb-2">Seller Dashboard</h1>
            <p className="text-muted-foreground">Manage your presentations and earnings</p>
          </div>
          <Button asChild className="mt-4 md:mt-0">
            <Link href="/sell">
              <Plus className="h-5 w-5 mr-2" />
              Upload New
            </Link>
          </Button>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          {stats.map((stat, index) => {
            const Icon = stat.icon
            return (
              <Card key={index} className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">{stat.label}</p>
                    <p className="text-2xl font-bold text-foreground">{stat.value}</p>
                  </div>
                  <Icon className={`h-8 w-8 ${stat.color} opacity-20`} />
                </div>
              </Card>
            )
          })}
        </div>

        {/* Presentations Table */}
        <Card className="p-6">
          <h2 className="text-2xl font-bold text-foreground mb-6">Your Presentations</h2>
          <SellerDashboardTable />
        </Card>
      </div>
    </main>
  )
}
