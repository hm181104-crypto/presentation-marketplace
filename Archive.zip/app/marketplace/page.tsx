"use client"

import { useState, useMemo } from "react"
import { usePresentations } from "@/lib/hooks"
import { MarketplaceFilters } from "@/components/marketplace-filters"
import { PresentationCard } from "@/components/presentation-card"

export default function MarketplacePage() {
  const { allPresentations, filterPresentations } = usePresentations()
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [minPrice, setMinPrice] = useState(0)
  const [maxPrice, setMaxPrice] = useState(100)
  const [selectedFileType, setSelectedFileType] = useState("all")
  const [selectedLevel, setSelectedLevel] = useState("all")

  const filteredResults = useMemo(() => {
    let filtered = allPresentations

    if (searchTerm) {
      filtered = filtered.filter(
        (p) =>
          p.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          p.description.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    }

    if (selectedCategory !== "all") {
      filtered = filtered.filter((p) => p.category === selectedCategory)
    }

    if (selectedFileType !== "all") {
      filtered = filtered.filter((p) => p.fileType === selectedFileType)
    }

    if (selectedLevel !== "all") {
      filtered = filtered.filter((p) => p.level === selectedLevel)
    }

    filtered = filtered.filter((p) => p.price >= minPrice && p.price <= maxPrice)

    return filtered
  }, [allPresentations, searchTerm, selectedCategory, minPrice, maxPrice, selectedFileType, selectedLevel])

  const handleFilterChange = (updates: any) => {
    if ("searchTerm" in updates) setSearchTerm(updates.searchTerm)
    if ("selectedCategory" in updates) setSelectedCategory(updates.selectedCategory)
    if ("minPrice" in updates) setMinPrice(updates.minPrice)
    if ("maxPrice" in updates) setMaxPrice(updates.maxPrice)
    if ("selectedFileType" in updates) setSelectedFileType(updates.selectedFileType)
    if ("selectedLevel" in updates) setSelectedLevel(updates.selectedLevel)
  }

  return (
    <main className="bg-background">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-foreground mb-2">Presentations Marketplace</h1>
          <p className="text-muted-foreground">Showing {filteredResults.length} results</p>
        </div>

        <div className="grid lg:grid-cols-4 gap-8">
          <div>
            <MarketplaceFilters
              onFilterChange={handleFilterChange}
              searchTerm={searchTerm}
              selectedCategory={selectedCategory}
              minPrice={minPrice}
              maxPrice={maxPrice}
              selectedFileType={selectedFileType}
              selectedLevel={selectedLevel}
            />
          </div>

          <div className="lg:col-span-3">
            {filteredResults.length > 0 ? (
              <div className="grid md:grid-cols-2 gap-6">
                {filteredResults.map((presentation) => (
                  <PresentationCard key={presentation.id} presentation={presentation} />
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-16 bg-muted/30 rounded-lg">
                <p className="text-lg text-muted-foreground mb-4">No presentations found</p>
                <p className="text-sm text-muted-foreground">Try adjusting your filters</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </main>
  )
}
