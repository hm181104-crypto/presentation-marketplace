import { LoginForm } from "@/components/login-form"

export default function LoginPage() {
  return (
    <main className="bg-background min-h-[calc(100vh-64px)] flex items-center justify-center px-4">
      <LoginForm />
    </main>
  )
}
