import { mockPurchases } from "@/lib/mock-purchases"
import { presentations } from "@/lib/mock-data"
import { PurchaseCard } from "@/components/purchase-card"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { DownloadCloud, ShoppingBag, Clock } from "lucide-react"

export default function BuyerDashboardPage() {
  const userPurchases = mockPurchases.filter((p) => p.buyerId === "buyer1")
  const totalSpent = userPurchases.reduce((sum, p) => sum + p.price, 0)
  const recentPurchase = userPurchases[0]

  const stats = [
    {
      icon: ShoppingBag,
      label: "Presentations Purchased",
      value: userPurchases.length,
      color: "text-primary",
    },
    {
      icon: DownloadCloud,
      label: "Total Downloaded",
      value: userPurchases.length,
      color: "text-accent",
    },
    {
      icon: Clock,
      label: "Total Spent",
      value: `$${totalSpent.toFixed(2)}`,
      color: "text-primary",
    },
  ]

  return (
    <main className="bg-background">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
          <div>
            <h1 className="text-4xl font-bold text-foreground mb-2">My Presentations</h1>
            <p className="text-muted-foreground">Manage your downloaded presentations</p>
          </div>
          <Button asChild className="mt-4 md:mt-0">
            <Link href="/marketplace">Browse More</Link>
          </Button>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-3 gap-4 mb-8">
          {stats.map((stat, index) => {
            const Icon = stat.icon
            return (
              <Card key={index} className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">{stat.label}</p>
                    <p className="text-2xl font-bold text-foreground">{stat.value}</p>
                  </div>
                  <Icon className={`h-8 w-8 ${stat.color} opacity-20`} />
                </div>
              </Card>
            )
          })}
        </div>

        {/* Purchases List */}
        {userPurchases.length > 0 ? (
          <div className="space-y-4">
            {userPurchases.map((purchase) => {
              const presentation = presentations.find((p) => p.id === purchase.presentationId)
              return presentation ? (
                <PurchaseCard key={purchase.id} purchase={purchase} presentation={presentation} />
              ) : null
            })}
          </div>
        ) : (
          <Card className="p-12 text-center">
            <ShoppingBag className="h-16 w-16 text-muted-foreground mx-auto mb-4 opacity-20" />
            <h2 className="text-2xl font-bold text-foreground mb-2">No Presentations Yet</h2>
            <p className="text-muted-foreground mb-6">Start exploring the marketplace to find presentations you need</p>
            <Button asChild>
              <Link href="/marketplace">Browse Marketplace</Link>
            </Button>
          </Card>
        )}
      </div>
    </main>
  )
}
