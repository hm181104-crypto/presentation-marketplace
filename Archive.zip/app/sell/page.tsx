import { UploadForm } from "@/components/upload-form"

export default function SellPage() {
  return (
    <main className="bg-background">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-foreground mb-2">Upload Your Presentation</h1>
          <p className="text-muted-foreground">Share your expertise and earn money from every sale</p>
        </div>

        <UploadForm />
      </div>
    </main>
  )
}
