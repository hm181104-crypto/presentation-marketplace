"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { presentations } from "@/lib/mock-data"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { SimilarPresentations } from "@/components/similar-presentations"
import { Star, Download, Share2, Heart, Users, Check } from "lucide-react"

interface PresentationDetailPageProps {
  params: Promise<{ id: string }>
}

export default function PresentationDetailPage({ params }: PresentationDetailPageProps) {
  const unwrappedParams = params instanceof Promise ? null : params
  const id = unwrappedParams?.id

  const [isWishlisted, setIsWishlisted] = useState(false)
  const [showPurchaseSuccess, setShowPurchaseSuccess] = useState(false)

  const presentation = presentations.find((p) => p.id === id)

  if (!presentation) {
    return (
      <main className="bg-background">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16 text-center">
          <h1 className="text-2xl font-bold text-foreground mb-2">Presentation not found</h1>
          <p className="text-muted-foreground mb-6">The presentation you're looking for doesn't exist.</p>
          <Button asChild>
            <Link href="/marketplace">Back to Marketplace</Link>
          </Button>
        </div>
      </main>
    )
  }

  const handlePurchase = () => {
    setShowPurchaseSuccess(true)
    setTimeout(() => setShowPurchaseSuccess(false), 3000)
  }

  return (
    <main className="bg-background">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
        <Link href="/marketplace" className="text-accent hover:text-accent/80 transition mb-6 inline-block">
          ← Back to Marketplace
        </Link>

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="relative h-96 md:h-[500px] bg-muted rounded-lg overflow-hidden mb-8">
              <Image
                src={presentation.thumbnail || "/placeholder.svg"}
                alt={presentation.title}
                fill
                className="object-cover"
              />
            </div>

            <Card className="p-6 mb-8">
              <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4">{presentation.title}</h1>
              <div className="flex flex-wrap gap-4 mb-6">
                <div className="flex items-center gap-2">
                  <Star className="h-5 w-5 fill-accent text-accent" />
                  <span className="font-semibold text-lg">{presentation.rating}</span>
                  <span className="text-muted-foreground">({presentation.reviewCount} reviews)</span>
                </div>
                <div className="h-1 w-1 bg-border rounded-full" />
                <div className="flex items-center gap-1 text-muted-foreground">
                  <Users className="h-5 w-5" />
                  <span>{presentation.reviewCount} purchases</span>
                </div>
              </div>

              <p className="text-lg text-muted-foreground mb-6">{presentation.description}</p>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 py-6 border-y border-border">
                <div>
                  <p className="text-sm text-muted-foreground">Category</p>
                  <p className="font-semibold text-foreground">{presentation.category}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">File Type</p>
                  <p className="font-semibold text-foreground">{presentation.fileType}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Level</p>
                  <p className="font-semibold text-foreground">{presentation.level}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Slides</p>
                  <p className="font-semibold text-foreground">{presentation.slideCount}</p>
                </div>
              </div>

              <div className="mt-6">
                <h3 className="font-semibold text-foreground mb-3">Created by</h3>
                <p className="text-muted-foreground">{presentation.creatorName}</p>
              </div>
            </Card>
          </div>

          <div>
            <Card className="p-6 sticky top-4">
              <div className="mb-6">
                <div className="text-5xl font-bold text-primary mb-2">${presentation.price}</div>
                <p className="text-sm text-muted-foreground">One-time purchase • Lifetime access</p>
              </div>

              {showPurchaseSuccess && (
                <div className="mb-4 p-4 bg-accent/10 border border-accent rounded-lg flex items-center gap-2">
                  <Check className="h-5 w-5 text-accent" />
                  <span className="text-sm font-medium text-accent">Purchase successful!</span>
                </div>
              )}

              <Button size="lg" className="w-full mb-3" onClick={handlePurchase}>
                <Download className="h-5 w-5 mr-2" />
                Buy Now
              </Button>

              <Button variant="outline" className="w-full mb-4 bg-transparent">
                <Share2 className="h-5 w-5 mr-2" />
                Share
              </Button>

              <Button variant="ghost" className="w-full" onClick={() => setIsWishlisted(!isWishlisted)}>
                <Heart className={`h-5 w-5 mr-2 ${isWishlisted ? "fill-destructive text-destructive" : ""}`} />
                {isWishlisted ? "Added to Wishlist" : "Add to Wishlist"}
              </Button>

              <div className="mt-6 pt-6 border-t border-border">
                <h4 className="font-semibold text-foreground mb-3">What's Included</h4>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex items-center gap-2">
                    <Check className="h-4 w-4 text-accent" />
                    Full presentation file
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="h-4 w-4 text-accent" />
                    Lifetime access
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="h-4 w-4 text-accent" />
                    Free updates
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="h-4 w-4 text-accent" />
                    Commercial license
                  </li>
                </ul>
              </div>
            </Card>
          </div>
        </div>

        <div className="mt-12 mb-8">
          <SimilarPresentations currentId={presentation.id} category={presentation.category} />
        </div>
      </div>
    </main>
  )
}
