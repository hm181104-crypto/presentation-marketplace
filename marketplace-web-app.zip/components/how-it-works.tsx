import { Card } from "@/components/ui/card"
import { Download, Upload, DollarSign, Users } from "lucide-react"

export function HowItWorks() {
  const steps = [
    {
      icon: Download,
      title: "Browse & Buy",
      description: "Explore thousands of professional presentations and purchase the ones you need.",
    },
    {
      icon: Users,
      title: "Instant Access",
      description: "Download your presentations immediately after purchase and start using them.",
    },
    {
      icon: Upload,
      title: "Create & Upload",
      description: "Create high-quality presentations and upload them to earn passive income.",
    },
    {
      icon: DollarSign,
      title: "Earn Money",
      description: "Earn money every time someone purchases your presentations.",
    },
  ]

  return (
    <section className="py-16 md:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">How It Works</h2>
          <p className="text-muted-foreground text-lg">Simple steps to get started</p>
        </div>
        <div className="grid md:grid-cols-4 gap-6">
          {steps.map((step, index) => {
            const Icon = step.icon
            return (
              <Card key={index} className="p-6 text-center flex flex-col items-center gap-4">
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Icon className="h-6 w-6 text-primary" />
                </div>
                <h3 className="font-semibold text-lg text-foreground">{step.title}</h3>
                <p className="text-sm text-muted-foreground">{step.description}</p>
              </Card>
            )
          })}
        </div>
      </div>
    </section>
  )
}
