import Link from "next/link"
import Image from "next/image"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import type { Presentation, Purchase } from "@/lib/types"
import { Download, Eye } from "lucide-react"

interface PurchaseCardProps {
  purchase: Purchase
  presentation: Presentation
}

export function PurchaseCard({ purchase, presentation }: PurchaseCardProps) {
  return (
    <Card className="overflow-hidden flex flex-col md:flex-row hover:shadow-lg transition">
      <div className="relative h-48 md:h-40 md:w-48 bg-muted flex-shrink-0">
        <Image
          src={presentation.thumbnail || "/placeholder.svg"}
          alt={presentation.title}
          fill
          className="object-cover"
        />
      </div>

      <div className="p-4 md:p-6 flex-1 flex flex-col justify-between">
        <div>
          <Link href={`/presentation/${presentation.id}`}>
            <h3 className="text-lg font-bold text-foreground hover:text-primary transition line-clamp-2">
              {presentation.title}
            </h3>
          </Link>
          <p className="text-sm text-muted-foreground mt-1">
            {presentation.category} • {presentation.fileType} • {presentation.slideCount} slides
          </p>
          <p className="text-xs text-muted-foreground mt-2">Purchased on {purchase.purchasedAt.toLocaleDateString()}</p>
        </div>

        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mt-4">
          <div className="text-2xl font-bold text-primary">${purchase.price}</div>
          <div className="flex gap-2">
            <Button size="sm">
              <Download className="h-4 w-4 mr-2" />
              Download
            </Button>
            <Button size="sm" variant="outline" asChild>
              <Link href={`/presentation/${presentation.id}`}>
                <Eye className="h-4 w-4 mr-2" />
                View
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </Card>
  )
}
