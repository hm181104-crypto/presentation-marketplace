"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { Upload } from "lucide-react"

interface UploadFormProps {
  onSubmit?: (formData: any) => void
}

export function UploadForm({ onSubmit }: UploadFormProps) {
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    price: "",
    category: "Business",
    fileType: "PPT",
    slideCount: "",
  })
  const [thumbnailFile, setThumbnailFile] = useState<File | null>(null)
  const [presentationFile, setPresentationFile] = useState<File | null>(null)
  const [submitted, setSubmitted] = useState(false)

  const categories = ["Business", "Education", "Marketing", "Sales", "Design", "Tech"]
  const fileTypes = ["PPT", "Google Slides", "Canva"]

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitted(true)
    if (onSubmit) {
      onSubmit(formData)
    }
    setTimeout(() => setSubmitted(false), 3000)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6 max-w-2xl">
      {submitted && (
        <Card className="p-4 bg-accent/10 border border-accent">
          <p className="text-sm font-medium text-accent">Presentation uploaded successfully!</p>
        </Card>
      )}

      <Card className="p-6">
        <h2 className="text-xl font-bold text-foreground mb-4">Presentation Details</h2>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">Title</label>
            <Input
              type="text"
              name="title"
              placeholder="Enter presentation title"
              value={formData.title}
              onChange={handleInputChange}
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-foreground mb-2">Description</label>
            <textarea
              name="description"
              placeholder="Describe your presentation"
              value={formData.description}
              onChange={handleInputChange}
              className="w-full px-3 py-2 border border-input rounded-md bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
              rows={4}
              required
            />
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Price ($)</label>
              <Input
                type="number"
                name="price"
                placeholder="29.99"
                value={formData.price}
                onChange={handleInputChange}
                step="0.01"
                min="0"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Number of Slides</label>
              <Input
                type="number"
                name="slideCount"
                placeholder="45"
                value={formData.slideCount}
                onChange={handleInputChange}
                min="1"
                required
              />
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Category</label>
              <select
                name="category"
                value={formData.category}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-input rounded-md bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
              >
                {categories.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-foreground mb-2">File Type</label>
              <select
                name="fileType"
                value={formData.fileType}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-input rounded-md bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
              >
                {fileTypes.map((type) => (
                  <option key={type} value={type}>
                    {type}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </Card>

      <Card className="p-6">
        <h2 className="text-xl font-bold text-foreground mb-4">Upload Files</h2>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">Thumbnail Image</label>
            <div className="border-2 border-dashed border-border rounded-lg p-6 text-center cursor-pointer hover:border-primary transition">
              <input
                type="file"
                accept="image/*"
                onChange={(e) => setThumbnailFile(e.target.files?.[0] || null)}
                className="hidden"
                id="thumbnail"
              />
              <label htmlFor="thumbnail" className="cursor-pointer flex flex-col items-center gap-2">
                <Upload className="h-8 w-8 text-muted-foreground" />
                <span className="text-sm font-medium">
                  {thumbnailFile ? thumbnailFile.name : "Click to upload thumbnail"}
                </span>
                <span className="text-xs text-muted-foreground">PNG, JPG up to 5MB</span>
              </label>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-foreground mb-2">Presentation File</label>
            <div className="border-2 border-dashed border-border rounded-lg p-6 text-center cursor-pointer hover:border-primary transition">
              <input
                type="file"
                accept=".ppt,.pptx,.key,.odp"
                onChange={(e) => setPresentationFile(e.target.files?.[0] || null)}
                className="hidden"
                id="presentation"
              />
              <label htmlFor="presentation" className="cursor-pointer flex flex-col items-center gap-2">
                <Upload className="h-8 w-8 text-muted-foreground" />
                <span className="text-sm font-medium">
                  {presentationFile ? presentationFile.name : "Click to upload presentation"}
                </span>
                <span className="text-xs text-muted-foreground">PPT, PPTX, KEY, ODP up to 100MB</span>
              </label>
            </div>
          </div>
        </div>
      </Card>

      <Button type="submit" size="lg" className="w-full">
        Upload Presentation
      </Button>
    </form>
  )
}
