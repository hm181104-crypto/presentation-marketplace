"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { presentations } from "@/lib/mock-data"
import { Edit2, Trash2, Eye } from "lucide-react"

export function SellerDashboardTable() {
  const sellerPresentations = presentations.filter((p) => p.creatorId === "creator1")

  return (
    <Card className="overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-muted/50 border-b border-border">
            <tr>
              <th className="px-6 py-3 text-left text-sm font-semibold text-foreground">Title</th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-foreground">Price</th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-foreground">Sales</th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-foreground">Rating</th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-foreground">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {sellerPresentations.map((presentation) => (
              <tr key={presentation.id} className="hover:bg-muted/30 transition">
                <td className="px-6 py-4 text-sm">
                  <Link href={`/presentation/${presentation.id}`} className="hover:text-primary transition">
                    {presentation.title}
                  </Link>
                </td>
                <td className="px-6 py-4 text-sm font-semibold text-foreground">${presentation.price}</td>
                <td className="px-6 py-4 text-sm text-foreground">{presentation.reviewCount}</td>
                <td className="px-6 py-4 text-sm">
                  <span className="text-accent font-semibold">{presentation.rating}</span>
                </td>
                <td className="px-6 py-4 text-sm">
                  <div className="flex items-center gap-2">
                    <Button size="sm" variant="ghost" asChild>
                      <Link href={`/presentation/${presentation.id}`}>
                        <Eye className="h-4 w-4" />
                      </Link>
                    </Button>
                    <Button size="sm" variant="ghost">
                      <Edit2 className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="ghost" className="text-destructive hover:text-destructive">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  )
}
