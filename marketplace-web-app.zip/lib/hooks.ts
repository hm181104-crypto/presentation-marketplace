"use client"

import { useState, useCallback } from "react"
import type { Presentation } from "./types"
import { presentations } from "./mock-data"

export function usePresentations() {
  const [allPresentations] = useState<Presentation[]>(presentations)
  const [filteredPresentations, setFilteredPresentations] = useState<Presentation[]>(presentations)

  const filterPresentations = useCallback(
    (searchTerm = "", category = "all", minPrice = 0, maxPrice = 100, fileType = "all", level = "all") => {
      let filtered = allPresentations

      if (searchTerm) {
        filtered = filtered.filter(
          (p) =>
            p.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
            p.description.toLowerCase().includes(searchTerm.toLowerCase()),
        )
      }

      if (category !== "all") {
        filtered = filtered.filter((p) => p.category === category)
      }

      if (fileType !== "all") {
        filtered = filtered.filter((p) => p.fileType === fileType)
      }

      if (level !== "all") {
        filtered = filtered.filter((p) => p.level === level)
      }

      filtered = filtered.filter((p) => p.price >= minPrice && p.price <= maxPrice)

      setFilteredPresentations(filtered)
    },
    [allPresentations],
  )

  return { filteredPresentations, filterPresentations, allPresentations }
}
