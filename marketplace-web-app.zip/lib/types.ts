export type FileType = "PPT" | "Google Slides" | "Canva"
export type Level = "Student" | "Business" | "Pitch Deck"
export type UserRole = "buyer" | "seller" | "both"

export interface User {
  id: string
  email: string
  name: string
  role: UserRole
  createdAt: Date
}

export interface Presentation {
  id: string
  title: string
  description: string
  price: number
  category: string
  fileType: FileType
  level: Level
  slideCount: number
  rating: number
  reviewCount: number
  creatorId: string
  creatorName: string
  thumbnail: string
  createdAt: Date
  updatedAt: Date
}

export interface Purchase {
  id: string
  buyerId: string
  presentationId: string
  price: number
  purchasedAt: Date
}

export interface Category {
  id: string
  name: string
  icon: string
}
